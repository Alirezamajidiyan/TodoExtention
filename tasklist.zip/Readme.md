# Task-Manager-simple

🔔 A simple and functional extension to manage tasks in your Chrome browser 💫

### how to install

1️⃣ First, you need to download the .zip file from this (link)[]

2️⃣ Then open the Chrome browser and search for `chrome://extensions/` in the address bar

❗ Note that developer-mode is active

3️⃣ Then click on Load Unpack and select the folder obtained by extracting the downloaded file

##### 🥳 Congratulations, the plugin has been successfully installed for you ✅

💯 Shortcut extension: `Ctrl+Shift+y`
